import io
import os
import sys

import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from feature_mapper import map_columns, normalize_type                      # noqa: E402
from pipeline import PipelineError, run_pipeline                            # noqa: E402

SAMPLES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sample_data")
FILES = ["sample_1_paysim_format.csv", "sample_2_bank_format.csv", "sample_3_messy_names.csv"]
EXPECTED = {"Type", "Amount", "Old_Balance_Orig", "New_Balance_Orig", "Old_Balance_Dest",
            "New_Balance_Dest", "Customer_ID", "Dest_ID", "Time_Step"}


def load(name):
    return pd.read_csv(os.path.join(SAMPLES, name))


# ---------------------------- feature mapper -------------------------------- #
@pytest.mark.parametrize("name", FILES)
def test_mapper_finds_all_core_fields(name):
    r = map_columns(load(name))
    assert r.ok and EXPECTED <= set(r.mapping)


def test_origin_and_destination_are_not_mixed_up():
    m = map_columns(load("sample_2_bank_format.csv")).mapping
    assert m["Old_Balance_Orig"] == "Sender_Balance_Before"
    assert m["New_Balance_Dest"] == "Receiver_Balance_After"
    m = map_columns(load("sample_3_messy_names.csv")).mapping
    assert m["Amount"] == "Txn_Amnt" and m["Old_Balance_Dest"] == "Beneficiary_Bal_Pre"


def test_type_found_by_content_when_name_is_useless():
    df = load("sample_1_paysim_format.csv").rename(columns={"type": "zzz_col"})
    r = map_columns(df)
    assert r.mapping["Type"] == "zzz_col" and "content" in [d for d in r.details if d["field"] == "Type"][0]["method"]


def test_text_column_is_not_accepted_as_amount():
    df = load("sample_1_paysim_format.csv")
    df["amount"] = "n/a"
    assert "Amount" not in map_columns(df).mapping


@pytest.mark.parametrize("raw,expected", [("cash out", "CASH_OUT"), ("CashIn", "CASH_IN"),
                                          ("Wire", "TRANSFER"), ("PAYMENT", "PAYMENT")])
def test_type_normalisation(raw, expected):
    assert normalize_type(raw) == expected


# ------------------------------- pipeline ----------------------------------- #
def test_same_data_in_three_layouts_gives_same_predictions():
    preds = [run_pipeline(load(f)).results_df.filter(like="Prediction").iloc[:, 0].tolist() for f in FILES]
    assert preds[0] == preds[1] == preds[2]


def test_pipeline_output_columns_and_summary():
    df = load(FILES[0])
    r = run_pipeline(df)
    assert {"Prediction", "Fraud_Probability"} <= set(r.results_df.columns)
    assert set(r.results_df["Prediction"]) <= {"Normal", "Suspicious"}
    assert r.results_df["Fraud_Probability"].between(0, 1).all()
    assert r.summary["total_transactions"] == len(df)
    assert r.summary["suspicious_count"] + r.summary["normal_count"] == len(df)


def test_obvious_account_drain_is_flagged():
    df = pd.DataFrame([{"type": "TRANSFER", "amount": 500000, "oldbalanceOrg": 500000, "newbalanceOrig": 0,
                        "oldbalanceDest": 0, "newbalanceDest": 0, "step": 10},
                       {"type": "PAYMENT", "amount": 50, "oldbalanceOrg": 10000, "newbalanceOrig": 9950,
                        "oldbalanceDest": 0, "newbalanceDest": 0, "step": 10}])
    out = run_pipeline(df).results_df
    assert out["Prediction"].tolist() == ["Suspicious", "Normal"]


def test_planted_fraud_recall_on_synthetic_data():
    s = run_pipeline(load(FILES[0])).summary["evaluation"]
    assert s["recall"] >= 0.9


def test_missing_required_columns_gives_clear_error():
    with pytest.raises(PipelineError, match="required column"):
        run_pipeline(pd.DataFrame({"foo": [1, 2], "bar": ["a", "b"]}))


def test_empty_dataframe_rejected():
    with pytest.raises(PipelineError):
        run_pipeline(pd.DataFrame())


def test_missing_values_are_handled():
    df = load(FILES[0]).head(100)
    df.loc[:5, "amount"] = None
    r = run_pipeline(df)
    assert len(r.results_df) == 100 and any("missing/invalid" in w for w in r.warnings)


# --------------------------------- web app ---------------------------------- #
@pytest.fixture
def client(tmp_path, monkeypatch):
    import app as appmod
    monkeypatch.setattr(appmod, "RESULTS_DIR", str(tmp_path))
    appmod.app.config["TESTING"] = True
    return appmod.app.test_client()


def upload(client, content, name="t.csv", **form):
    return client.post("/predict", data={"file": (io.BytesIO(content), name), **form},
                       content_type="multipart/form-data")


def test_frontend_files_served_and_private_files_not(client):
    assert client.get("/").status_code == 200 and b"FraudGuard" in client.get("/").data
    assert client.get("/main.js").status_code == 200 and client.get("/style.css").status_code == 200
    for private in ("/app.py", "/fraud_detection_model.pkl", "/pipeline.py", "/requirements.txt"):
        assert client.get(private).status_code == 404


def test_health_and_samples(client):
    assert client.get("/health").get_json()["status"] == "ok"
    assert client.get("/samples/sample_1_paysim_format.csv").status_code == 200
    assert client.get("/samples/secret.csv").status_code == 404


def test_predict_and_download_flow(client):
    with open(os.path.join(SAMPLES, FILES[1]), "rb") as f:
        r = upload(client, f.read())
    j = r.get_json()
    assert r.status_code == 200 and j["summary"]["suspicious_count"] > 0
    assert len(j["hist"]) == 10 and j["top"]["rows"] and j["mapping"]
    d = client.get("/download/" + j["download_id"])
    assert d.status_code == 200 and b"Fraud_Probability" in d.data


def test_rejects_non_csv_empty_and_garbage(client):
    for content, name in [(b"hello", "x.txt"), (b"", "x.csv"), (b"a,b\n", "x.csv"), (b"foo,bar\n1,2\n", "x.csv")]:
        r = upload(client, content, name)
        assert r.status_code == 400 and "error" in r.get_json()


def test_bad_threshold_and_bad_download_id(client):
    with open(os.path.join(SAMPLES, FILES[0]), "rb") as f:
        assert upload(client, f.read(), threshold="abc").status_code == 400
    assert client.get("/download/notanid").status_code == 400
    assert client.get("/download/" + "0" * 32).status_code == 404


def test_json_api(client):
    r = client.post("/api/predict", json={"type": "TRANSFER", "amount": 900000, "oldbalanceOrg": 900000,
                                          "newbalanceOrig": 0, "oldbalanceDest": 0, "newbalanceDest": 0})
    j = r.get_json()
    assert r.status_code == 200 and j["results"][0]["prediction"] == "Suspicious"
    assert client.post("/api/predict", json={"x": 1}).status_code == 400


# ------------------------- locale-formatted numbers ------------------------- #
def test_thousand_separators_and_decimal_commas_are_understood():
    from feature_mapper import _num
    s = pd.Series(["1,234.50", "1.234,50", "123,45", "$ 99", "1,000", "abc", None])
    out = _num(s).tolist()
    assert out[:5] == [1234.5, 1234.5, 123.45, 99.0, 1000.0]
    assert pd.isna(out[5]) and pd.isna(out[6])


def test_semicolon_csv_with_decimal_comma_end_to_end(client):
    raw = load(FILES[0]).head(200).to_csv(index=False, sep=";", decimal=",").encode()
    r = upload(client, raw)
    assert r.status_code == 200 and r.get_json()["summary"]["total_transactions"] == 200


def test_portable_json_model_matches_legacy_pickle():
    import numpy as np
    from pipeline import LEGACY_PKL, engineer_features, load_model
    from feature_mapper import understand_and_standardize
    std = understand_and_standardize(load(FILES[0]))[0]
    new = load_model()
    X = engineer_features(std, new["feature_columns"])
    p_new = new["model"].predict_proba(X)[:, 1]
    if os.path.exists(LEGACY_PKL):
        import joblib
        old = joblib.load(LEGACY_PKL)
        assert np.allclose(p_new, old["model"].predict_proba(X)[:, 1], atol=1e-6)
    assert new["model_name"] == "XGBoost" and p_new.max() > 0.9
